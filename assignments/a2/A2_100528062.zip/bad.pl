! declare x = 3;
double y = 0;
int z = 0;
while (x < 10) or (y < 20) {
  x = x + 1;
  y = y + 2;
  z = 2*x + y;
  print(x+y, z);
}
